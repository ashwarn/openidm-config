
Copyright
=============
Copyright 2016-2017 ForgeRock AS. All Rights Reserved

Use of this code requires a commercial software license with ForgeRock AS.
or with one of its affiliates. All use shall be exclusively subject
to such license between the licensee and ForgeRock AS.

Configuration Example: Unconfigured AM Server
=============================================

This sample populates an AM server with no configuration. 
Point the Amster import at this folder to get a no-op import.


Copyright
=============
Copyright 2014-2017 ForgeRock AS. All Rights Reserved

Use of this code requires a commercial software license with ForgeRock AS.
or with one of its affiliates. All use shall be exclusively subject
to such license between the licensee and ForgeRock AS.

Bi-directional LDAP Sync With Internal Repository Sample
========================================================

This sample demonstrates bidirectional synchronization between an LDAP directory
and an OpenIDM repository. For documentation relating to this sample, see
https://ea.forgerock.com/docs/openidm/doc/samples-guide/index.html#chap-sync-with-ldap-bidirectional

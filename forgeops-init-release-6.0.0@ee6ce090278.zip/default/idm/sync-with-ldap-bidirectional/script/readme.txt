All customized JavaScript files for the configuration should go into this directory.

Default copies are found under bin/default/script - place them here and update the script references in the
appropriate conf file rather than modifying the bin/default/script copy.
